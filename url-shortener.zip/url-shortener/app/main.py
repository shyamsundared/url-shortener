from flask import Flask, jsonify,request,redirect

from .models import lock,mp,shorturl
from .utils import randomizer,validurl,isunique
app = Flask(__name__)

@app.route('/')
def health_check():
    return jsonify({
        "status": "healthy",
        "service": "URL Shortener API"
    })

@app.route('/api/health')
def api_health():
    return jsonify({
        "status": "ok",
        "message": "URL Shortener API is running"
    })
base="http://localhost:5000"
@app.route('/api/shorten',methods=['POST'])
def shortenurl():
    req=request.get_json()#convert from json to python dict
    req = request.get_json()
    if not req:
        return jsonify({"error": "Invalid or missing JSON body"}), 400

    url=req.get("url")
    if not url:
        return jsonify({"error":"there is no url provided"}),400
    if not validurl(url):
        return jsonify({"error":"its not a valid url"}),400
    scode=randomizer()
    with lock:
        while not isunique(scode):
            scode=randomizer()
        
        mp[scode]=shorturl(url,scode)
        return jsonify({"short_code":scode,"short_url":f"{base}/{scode}"}),201
@app.route('/<short_code>',methods=['GET'])
def redirecturl(short_code):
    with lock:
        data=mp.get(short_code)
        if not data:
            return jsonify({"error":"no short code found"}),404
        data.clicks+=1
        return redirect(data.url)    

@app.route("/api/stats/<short_code>",methods=["GET"])
def getanalytics(short_code):
    
        data=mp.get(short_code)
        if not data:
            return jsonify({"error":"no short code found"}),404
        return jsonify({ "url": data.url, "clicks": data.clicks, "created_at": data.created_at})
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)