# TODO: Implement your data models here
# Consider what data structures you'll need for:
# - Storing URL mappings
# - Tracking click counts
# - Managing URL metadata
from datetime import datetime
from threading import Lock
class shorturl():
    def __init__(self,url,scode):
        self.url=url
        self.scode=scode
        self.created_at=datetime.utcnow()
        self.clicks=0
    def clickcounter(self):
        self.clicks+=1

mp={}
lock=Lock()