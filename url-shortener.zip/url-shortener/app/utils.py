# TODO: Implement utility functions here
# Consider functions for:
# - Generating short codes
# - Validating URLs
# - Any other helper functions you need

import random

from .models import mp
from urllib.parse import urlparse

def randomizer():
    
    s='0123456789abcdefghijklmnopqrstuvwxyz'
    l=''.join(random.choices(s,k=6))
    return l
def isunique(shortcode):
    if shortcode in mp:
        return False
    else:
        return True
def validurl(url):
    parsed = urlparse(url)
    return parsed.scheme in ('http', 'https') and bool(parsed.netloc)