import pytest
from app.main import app

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_health_check(client):
    response = client.get('/')
    assert response.status_code == 200
    data = response.get_json()
    assert data['status'] == 'healthy'
    assert data['service'] == 'URL Shortener API'
 




def test_shorten_valid_url(client):
    url = "https://www.example.com/very/long/url"
    res = client.post('/api/shorten', json={"url": url})
    assert res.status_code == 201
    data = res.get_json()
    assert 'short_code' in data
    assert 'short_url' in data
    assert data['short_url'].startswith('http://localhost:5000/')

def test_shorten_invalid_url(client):
    
    res = client.post('/api/shorten', json={"url": "not a url"})
    assert res.status_code == 400
    data = res.get_json()
    assert 'error' in data

def test_redirect_link(client):
    
    url = "https://www.example.com/test"
    res = client.post('/api/shorten', json={"url": url})
    code = res.get_json()['short_code']

    redirect_res = client.get(f'/{code}', follow_redirects=False)
    assert redirect_res.status_code in [301, 302]
    assert redirect_res.headers['Location'] == url

def test_analytics(client):
   
    url = "https://www.example.com/anucwijwea"
    res = client.post('/api/shorten', json={"url": url})
    code = res.get_json()['short_code']

    
    client.get(f'/{code}')
    client.get(f'/{code}')

    stats = client.get(f'/api/stats/{code}')
    assert stats.status_code == 200
    data = stats.get_json()
    assert data['url'] == url
    assert data['clicks'] == 2
    assert 'created_at' in data

def test_redirect_not_found(client):
    
    res = client.get('/unknowncode')
    assert res.status_code == 404
    data = res.get_json()
    assert 'error' in data

def test_stats_not_found(client):
    
    res = client.get('/api/stats/unknowncode')
    assert res.status_code == 404
    data = res.get_json()
    assert 'error' in data
